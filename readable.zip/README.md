## Requirements

You will need to have the API server running, you can get it from: [API server](https://github.com/udacity/reactnd-project-readable-starter)

## Instructions
To start the application you will need to:

- Install dependencies with *yarn*
- Start the server with *yarn start*
